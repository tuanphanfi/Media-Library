
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="styles.css">
    </head>
    <body>
        <p>Chuong Pham 1702219</p>
        <table>
            <?php
                $i = 1;

                while ($i<=100){
                    //Start 1 row
                    echo "<tr>";

                    //Only 10 numbers on the row
                    for($count = 1; $count <=10; $count++){
                        echo"<td>".$i."</td>";
                        $i++;
                    }

                    //End 1 row
                    echo "</tr>";
                }
            ?>
        </table>
    </body>
</html>
